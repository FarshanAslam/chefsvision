<?php
require_once 'header.php';
?>
<div class = "thanks-msg">
<p>Thank you <?php $_POST['name'] ?> to contact us.</p>
</div>

<?php
require_once 'footer.php';
?>